var customers = [
  {
    name:'AyHam',
    date: '6/05/2022',
    repeated: false
  },

  {
    name:'Rajat',
    date: '7/05/2022',
    repeated: false
  },

  {
    name:'Jimmy',
    date: '2/05/2022',
    repeated:false
  },

  {
    name:'AyHam',
    date: '5/05/2022',
    repeated: false
  },

  {
    name:'AyHam',
    date: '3/05/2022',
    repeated: false
  },

  {
    name:'Jimmy',
    date: '4/05/2022',
    repeated: false
  },
];

for(let i=0; i<customers.length; ++i)
{
  for(let j=0; j<customers.length; ++j)
    {
      if(i!=j)
      {
        if(customers[i].name == customers[i].name)
        {
          console.log(customers[i].name,"is repeated");
          break;
        }
        }
      }
    }